from flask import Flask, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy

# Configurações do Flask
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"
db = SQLAlchemy(app)

# Banco de dados - Modelo
class Produto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(50))
    marca = db.Column(db.String(50))
    preco = db.Column(db.Float)
    imagem = db.Column(db.String)

    def __init__(self, nome, marca, preco, imagem):
        self.nome = nome
        self.marca = marca
        self.preco = preco
        self.imagem = imagem

# Cria o banco de dados
with app.app_context():
    db.create_all()

# Cria uma url
@app.route('/')
def produtos():
    # Envia um HTML
    return render_template('produtos.html', produtos=Produto.query.all())


@app.route('/criar_produtos', methods=["GET", "POST"]) # Permite enviar POST
def criar_produto():
    nome = request.form.get('nome')
    marca = request.form.get('marca')
    preco = request.form.get('preco')
    imagem = request.form.get('imagem')

    # Roda se for POST
    if request.method == 'POST':
        produto = Produto(nome, marca, preco, imagem)
        db.session.add(produto)
        db.session.commit()
        return redirect(url_for('produtos'))

    return render_template("novo_produto.html")

# Recebe um valor
@app.route('/<int:id>/atualizar_produto', methods=["GET", "POST"])
def atualizar_produto(id):
    # Busca no banco de dados
    produto = Produto.query.filter_by(id=id).first()
    if request.method == 'POST':
        nome = request.form.get('nome')
        marca = request.form.get('marca')
        preco = request.form.get('preco')
        imagem = request.form.get('imagem')

        produto.query.filter_by(id=id).update(
            {"nome": nome, "marca": marca, "preco": preco, "imagem": imagem})
        db.session.commit()
        return redirect(url_for('produtos'))
    return render_template("atualizar_produto.html", produto=produto)


@app.route('/<int:id>/remover_produto')
def remover_produto(id):
    produto = Produto.query.filter_by(id=id).first()
    db.session.delete(produto)
    db.session.commit()
    return redirect(url_for('produtos'))


@app.route('/<int:id>')
def visualizar_produto(id):
    produto = Produto.query.filter_by(id=id).first()
    return render_template("visualizar_produto.html", produto=produto)


# Roda o código
if __name__ == "__main__":
    app.run(debug=True)
